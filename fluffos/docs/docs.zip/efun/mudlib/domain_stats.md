---
layout: doc
title: mudlib / domain_stats
---
# domain_stats

### NAME

    domain_stats() - returns statistics gathered on domains
    author_stats() - returns statistics gathered on authors

### SYNOPSIS

    mapping domain_stats( string domain | void );
    mapping author_stats( string domain | void );

### DESCRIPTION

    Both  domain_stats()  and author_stats() return information stored in a
    mapping.  If no argument is specified, then information is returned  on
    all  domains  (or  on  all  authors)  with  one map entry per domain or
    author.  If an argument is specified, then a map is returned that  cor‐
    responds  to  that  domain  or  author  with keys: moves, cost, errors,
    heart_beats, worth, array_size, and objects.   Each  of  these  map  to
    integer  values.   Moves  is the number of objects that have moved into
    objects in the  given  domain.   Cost  is  the  number  of  evaluations
    (eval_cost)  accumulated  by objects with the given domain (or author).
    Errors is the number of errors  incurred  by  objects  with  the  given
    domain.   Heart_beats  is the number of heartbeat calls made on objects
    having the  given  domain.   Worth  is  the  value  maintained  by  the
    add_worth(3)  efunction (this is usually used to keep track of how much
    money a given wizard has given out vs. taken in).   Array_size  is  the
    size  (in bytes) of the arrays allocated by the domain.  Objects is the
    number of objects created by the given domain.   When  called  with  no
    arguments, the returned mapping has a form like this:

        ([ domain0 : info0, domain1 : info1, ... ])

    while info0 has the form:

        ([ "moves" : moves, "cost" : cost, "errors" : errors,
           "heart_beats" : heart_beats, "worth" : worth,
           "array_size" : array_size, "objects" : objects ])

    When  called  with an argument, the returned mapping will have the form
    of info0.

### SEE ALSO

    domain_file(4), author_file(4), set_author(3)

